import DigitalLearningApp from "./DigitalLearningApp";

export default function App() {
  return <DigitalLearningApp />;
}
